# Assignment - 03

## Codekit Setup:

Download the current repo and copy the `w-03-02-html-structure` files into your own folder. Go into Codekit and import this folder as a new "project". Use this is a starter for your HW.

## Adding your HTML Structure

Using the `w-03-02-html-structure` template, start adding your HTML structure to match your figma file from week 1. Use the in class demo as an example. Include images, text.

## Submission

Submit your github link to blackboard under "Assignment 03".

Submission example

```
Github: {github-link-to-your-project}
Figma File: {link to figma}
```
