# Assignment - 02

## Codekit Setup:

Using your existing repo, ensure that you set up your project correctly for this class. Using the video provided in class, your project should have the following setup:

- deploy
  - index.html
- dev
  - index.kit

Inside these files, you should have the basic html markup (Match the video). Once you've created the basic markup, you can push your code to your github using the github desktop app and submit a link.

## Reading

Read Chapters 10 - 13 of "HTML & CSS: Design and Build Web Sites" by John Duckett

## Submission

Submit your github link to blackboard under "Assignment 02".

Submission example

```
Github: {github-link-to-your-project}
```
